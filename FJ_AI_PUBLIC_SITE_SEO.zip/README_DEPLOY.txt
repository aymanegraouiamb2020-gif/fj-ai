FJ AI — publication gratuite sans domaine

1) Publier sur Vercel : https://vercel.com/new
2) Importer ce dossier et déployer.
3) Vercel fournit une URL gratuite en *.vercel.app.
4) Remplacer YOUR-PROJECT.vercel.app dans index.html, robots.txt et sitemap.xml par l'URL réelle.
5) Google Search Console : ajouter l'URL exacte comme propriété URL-prefix.
6) Dans Search Console > Sitemaps : envoyer https://TON-URL.vercel.app/sitemap.xml
7) Dans Inspection d'URL : demander l'indexation de la page d'accueil.

Google peut afficher le nom du site, le favicon, le titre et un extrait, mais leur affichage n'est pas garanti et peut prendre du temps.

Le flux FinancialJuice réel doit passer par une source dont l'utilisation est autorisée (RSS/widget/API/licence). Cette démo contient des données de présentation.
